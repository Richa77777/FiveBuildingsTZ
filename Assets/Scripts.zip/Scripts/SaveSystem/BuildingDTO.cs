using System;
using UnityEngine;

[Serializable]
public class BuildingDTO
{
    public string id;
    public int currentResource;
}
